Welcome to Tatjam's Map Viewer.

This thing reads Dwarf Fortress exported maps and creates a better map for viewing mixing biome and elevation data.

Open the executable for more information, and keybindings.

If you get a missing dll error message install Visual Studio 2015 redistributable (included)

Credits:

SFML (The graphics library used)
Toady One (Dwarf Fortress)
Microsoft (C lib)

The program is licensed under the MIT license, and can be found in Github, check the forum page for information!
